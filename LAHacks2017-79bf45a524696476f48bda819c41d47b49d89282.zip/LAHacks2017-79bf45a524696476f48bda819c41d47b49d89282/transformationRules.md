enum RubixThingies {


};


std::vector<stuff> = #include "table1.inc";

{
  {{1, 1}, {2, 2}}
}
