
#include <iostream.h>

class CPuzAssocTbl
{
	
};